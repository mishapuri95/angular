import { Injectable } from '@angular/core';
import { HEROES } from 'src/app/heroes/mock-hero';
import { Hero } from 'src/app/hero';
import { Observable, of } from 'rxjs';
import { MessageService } from 'src/app/message.service';


@Injectable({
  providedIn: 'root'
})
export class HeroService {
  
  constructor(public messageService: MessageService) { }

  getHero() : Observable<Hero[]> {
    this.messageService.add('heroes list fetched successfully!')
   return of (HEROES);
 }  
}
