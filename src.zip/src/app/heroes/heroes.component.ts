
import {Component} from '@angular/core';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { Hero } from '../hero';
import { mockHero } from './mock-hero'

@Component({
  selector: 'hero-comp',
  templateUrl: 'heroes.component.html',
  styleUrls: ['heroes.component.css']
})

export class HeroesComponent implements OnInit {
 public myvar: string;
  constructor(){
    this.myvar = "manisha";
    }
  public hero : Hero = {
    id: 2,
    name: "mish"
  }
  public heroArray = mockHero ;
 
    ngOnInit(){}

  }

 
  


